<?php if(session()->has('out')): ?>
<h1><?php echo e($out); ?></h1>
<?php else: ?>
<h1>Thank you!</h1>
<?php endif; ?>

<script>
    history.pushState(null, null, document.URL);
    window.addEventListener('popstate', function () {
        history.pushState(null, null, document.URL);
    });
</script><?php /**PATH C:\xampp1\htdocs\jcaDep\resources\views/jcajudges/home/logout.blade.php ENDPATH**/ ?>