

<?php $__env->startSection('content'); ?>

   <?php if($events->count() > 0): ?>
   <div class="indexCont rounded-3 px-4 pt-4">

    <?php if(session('loggedIn')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('loggedIn')); ?>

      </div>
    <?php endif; ?>

    <?php if(session('eventDeleted')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('eventDeleted')); ?>

      </div>
    <?php endif; ?>
    <?php if(session('eventUpdated')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('eventUpdated')); ?>

      </div>
    <?php endif; ?>

    <?php echo $__env->make('facilitator.dashboard.addEvent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table class="table">
        <thead>
            <tr>
                <th>Event</th>
                <th>Location</th>
                <th>Preliminary (Date)</th>
                <th>Preliminary (Time)</th>
                <th>Semi/final (Date)</th>
                <th>Semi/final (Time)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
           <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
            <td><?php echo e($event->title); ?></td>
            <td><?php echo e($event->location); ?></td>
            <td><?php echo e($event->preliminaryDate); ?></td>
            <td><?php echo e($event->preliminaryStartTime); ?></td>
            <td><?php echo e($event->finalDate); ?></td>
            <td><?php echo e($event->finalStartTime); ?></td>
            <td class="d-flex gap-2">



                <?php echo $__env->make('facilitator.dashboard.editEvent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div>
                        <a href="<?php echo e(route('eventShow.show', [
                        'event' => $event->id
                    ])); ?>" class="btn btn-success"><i class="fa fa-eye"></i></a>
                    </div>




                    <!-- Button trigger modal -->


                    <div>
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#event<?php echo e($event->id); ?>"><i class="fa fa-trash"></i></button>
                    </div>


  <form action="<?php echo e(route('event.delete', [
    'event' => $event->id
])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>


    <div class="modal fade" id="event<?php echo e($event->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Event</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <p>Are you sure to delete event <span class="text-bold"><?php echo e($event->title); ?></span> ?</p>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-danger">Yes</button>
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div>
          </div>
        </div>
      </div>
</form>




                    




               

            </td>
           
        </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>
</div>
   <?php else: ?>
       
   <?php echo $__env->make('facilitator.dashboard.addEvent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
   <?php endif; ?>

    
<?php $__env->stopSection(); ?>


<style>
.indexCont{
    width: 100%;
}
    </style>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\jcaDep\resources\views/facilitator/dashboard/index.blade.php ENDPATH**/ ?>