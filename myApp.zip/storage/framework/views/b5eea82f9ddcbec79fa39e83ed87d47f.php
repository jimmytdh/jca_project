<?php $__env->startSection('eventHeader'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Contestant</h1>
                </div>
                <div class="col-sm-6">

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('eventContent'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Registered contestant</h3>


            <?php echo $__env->make('facilitator.singleEvent.contestants.addContestantModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




        </div>
        <div class="card-body p-0">
            <table class="table table-sm table-bordered">
                <thead>
                    <tr>
                        <th>Number</th>
                        <th>Address</th>
                        <th>Photo</th>
                        <th>Age</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $contestants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contestant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($contestant->contestantNum); ?>. <?php echo e($contestant->name); ?></th>
                            <td><?php echo e($contestant->address); ?></td>
                            <td>
                                <?php echo e($contestant->id); ?>

                                
                            </td>
                            <td><?php echo e($contestant->age); ?></td>
                            <td class="d-flex gap-2">

                                <div>
                                    <?php echo $__env->make('facilitator.singleEvent.contestants.editContestant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <form method="POST"
                                    action="<?php echo e(route('contestant.delete', [
                                        'contestant' => $contestant->id,
                                        'event' => $event->id,
                                    ])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-danger btn btn-sm"><i
                                            class="fa fa-trash"></i></button>
                                </form>

                                <div>
                                    <?php echo $__env->make('facilitator.singleEvent.contestants.viewContestant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>


    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.eventLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\jcaDep\resources\views/facilitator/singleEvent/contestants/index.blade.php ENDPATH**/ ?>