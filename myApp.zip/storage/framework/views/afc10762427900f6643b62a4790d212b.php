





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(session('event_name')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <nav class="main-header navbar navbar-expand navbar-white navbar-light d-flex flex-column align-items-start">
            <h4><?php echo e(session('event_name')); ?></h4>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i
                            class="fas fa-bars"></i></a>
                </li>
                <?php echo $__env->yieldContent('judgesNavs'); ?>
            </ul>

        </nav>


        <aside class="main-sidebar sidebar-dark-primary elevation-4">

            <div class="sidebar">

                <div class="user-panel mt-3 pb-3 mb-3 d-flex flex-column align-items-center">
                    <div class="image">
                        <img src="/Image/missq.jpg" class="img-circle" style="width: 100px; height: 100px; border-radius: 50%;" alt="User Image">
                    </div>
                    <div class="info">
                        <a href="#" class="d-block"><?php echo e(session('judge_name')); ?></a>
                    </div>
                </div>



                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">



                        <li class="nav-item">
                            <a href="<?php echo e(route('event.index')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-calendar"></i>
                                <p>Cover</p>
                            </a>
                        </li>


                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.logout')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-unlock"></i>
                                <p>Logout</p>
                            </a>
                        </li>

                    </ul>
                </nav>

            </div>

        </aside>

        <div class="content-wrapper">

           <?php echo $__env->yieldContent('eventHeader'); ?>


            <section class="content">
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('judgesCont'); ?>
                </div>
            </section>

        </div>
    </div>



    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
    <?php echo $__env->yieldContent('judgingScript'); ?>
</body>

</html>
<?php /**PATH C:\xampp1\htdocs\jcaDep\resources\views/layout/judgesLayout.blade.php ENDPATH**/ ?>