





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AdminLTE 3 | Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <div class="preloader flex-column justify-content-center align-items-center">

        </div>

        <nav class="main-header navbar navbar-expand navbar-white navbar-light d-flex flex-column align-items-start">
            <h3><?php echo e($event->title); ?></h3>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i
                            class="fas fa-bars"></i></a>
                </li>

                <li class="nav-item d-none d-sm-inline-block"><a
                        href="<?php echo e(route('preliminaryRatings.index', ['event' => $event->id])); ?>"
                        class="nav-link">Pre-interview</a></li>
                <li class="nav-item d-none d-sm-inline-block"><a
                        href="<?php echo e(route('swimwearRatings.index', ['event' => $event->id])); ?>"
                        class="nav-link">Swimwear</a></li>
                <li class="nav-item d-none d-sm-inline-block"><a
                        href="<?php echo e(route('gownRatings.index', ['event' => $event->id])); ?>" class="nav-link">Gown</a></li>
                <li class="nav-item d-none d-sm-inline-block"><a
                        href="<?php echo e(route('ranking.index', ['event' => $event->id])); ?>" class="nav-link">Ranking</a></li>
                <li class="nav-item d-none d-sm-inline-block"><a
                        href="<?php echo e(route('semifinalAdmin.index', ['event' => $event->id])); ?>"
                        class="nav-link">Semifinal</a></li>
                <li class="nav-item d-none d-sm-inline-block"><a
                        href="<?php echo e(route('finalRatings.index', ['event' => $event->id])); ?>" class="nav-link">Final</a>
                </li>

            </ul>

        </nav>


        <aside class="main-sidebar sidebar-dark-primary elevation-4">

            <div class="sidebar">

                <div class="user-panel mt-3 pb-3 mb-3 d-flex flex-column align-items-center">
                    <div class="image">
                        <img src="/Image/missq.jpg" class="img-circle" style="width: 100px; height: 100px; border-radius: 50%;" alt="User Image">
                    </div>
                    <div class="info">
                        <a href="#" class="d-block">Administrator</a>
                    </div>
                </div>



                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">



                        <li class="nav-item">
                            <a href="<?php echo e(route('event.index')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-calendar"></i>
                                <p>Events</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('contestant.index', ['event' => $event->id])); ?>" class="nav-link">
                                <i class="nav-icon fas fa-users"></i>
                                <p>Contestant</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('eventShow.show', ['event' => $event->id])); ?>" class="nav-link">
                                <i class="nav-icon fas fa-user-plus"></i>
                                <p>Judges</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.logout')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-unlock"></i>
                                <p>Logout</p>
                            </a>
                        </li>

                    </ul>
                </nav>

            </div>

        </aside>

        <div class="content-wrapper">

           <?php echo $__env->yieldContent('eventHeader'); ?>


            <section class="content">
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('eventContent'); ?>
                </div>
            </section>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>




<?php /**PATH C:\xampp1\htdocs\jcaDep\resources\views/layout/eventLayout.blade.php ENDPATH**/ ?>